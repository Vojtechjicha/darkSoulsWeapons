const express = require('express');
const path = require('path');
const app = express();

// Nastavení statické složky pro soubory
app.use(express.static(path.join(__dirname, 'public')));

// Middleware pro práci s JSON
// app.use(express.json());

app.get('/api/data', (req, res) => {
    res.sendFile(path.join(__dirname, 'public/dark_souls_weapons.json'));
});

app.get('/', (req, res) => {
    res.send('Hello, Express!');
});

// app.get('/api/users', (req, res) => {
//     res.json([
//         { id: 1, name: "Jan" },
//         { id: 2, name: "Anna" }
//     ]);
// });

// app.post('/api/users', (req, res) => {
//     const newUser = req.body; // Data z klienta
//     res.status(201).json({ message: "Uživatel vytvořen", user: newUser });
// });

app.listen(3000, () => {
    console.log('Server běží na http://localhost:3000');
});